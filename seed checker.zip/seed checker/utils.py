import sys
import os
import platform

from openpyxl import Workbook
from openpyxl import load_workbook
from openpyxl.styles import Font


class bcolors:
    BLUE = "\033[94m"
    CYAN = "\033[96m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    END = "\033[0m"


def clear():
    os.system("cls" if os.name == "nt" else "clear")


def set_title(title):
    system_type = platform.system()
    if system_type == "Windows":
        os.system("title " + title)
    elif system_type == "Linux":
        print(f"\33]0;{title}\a", end="", flush=True)


def get_run_path():
    if getattr(sys, "frozen", False):
        app_path = os.path.dirname(sys.executable)
    else:
        try:
            app_path = os.path.dirname(os.path.realpath(__file__))
        except NameError:
            app_path = os.getcwd()
    return app_path


def get_file_path(file_name):
    return os.path.join(get_run_path(), file_name)


def write_to_excel(new_row, filename, mode):
    try:
        try:
            wb = load_workbook(filename)
            ws = wb.worksheets[0]
        except FileNotFoundError:
            if mode == "balance":
                headers_row = ["Seed", "Private Key", "Address", "Depth", "Chain", "Balance ($)"]
            else:
                headers_row = ["Seed", "Private Key", "Address", "Depth", "Chain", "Transactions"]
            wb = Workbook()
            ws = wb.active
            ws.append(headers_row)
            ws["A1"].font = Font(bold=True)
            ws["B1"].font = Font(bold=True)
            ws["C1"].font = Font(bold=True)
            ws["D1"].font = Font(bold=True)
            ws["E1"].font = Font(bold=True)
            ws["F1"].font = Font(bold=True)

        ws.append(new_row)
        wb.save(filename)
    except:
        pass