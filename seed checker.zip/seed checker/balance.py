import requests
import random
import time
import utils
import blocksmith

from fake_useragent import UserAgent
from hdwallet import BIP44HDWallet
from hdwallet.cryptocurrencies import EthereumMainnet, LitecoinMainnet, DogecoinMainnet, DashMainnet, BitcoinMainnet
from hdwallet.derivations import BIP44Derivation


def defi_mnemonic(selected_chains_evm, proxy_list, path_results, depth, mnemonic):
    for i in range(depth):
        try:
            bip44_hdwallet: BIP44HDWallet = BIP44HDWallet(cryptocurrency=EthereumMainnet)
            bip44_hdwallet.from_mnemonic(mnemonic=mnemonic)
            bip44_hdwallet.clean_derivation()
            bip44_derivation: BIP44Derivation = BIP44Derivation(cryptocurrency=EthereumMainnet, account=i, change=False, address=0)
            bip44_hdwallet.from_path(path=bip44_derivation)
            private_key = bip44_hdwallet.private_key()
            address = bip44_hdwallet.address()
        except:
            return 0
        
        for chain_id, chain_name in selected_chains_evm.items():
            while True:
                try:
                    ua = UserAgent()
                    url = f"https://api.de.fi/v1/balances-v2?addresses[]={address}&chains[]={chain_id}"
                    headers = {
                        "User-Agent": ua.random,
                        "Pragma": "no-cache",
                        "Accept": "*/*",
                        "origin": "https://de.fi",
                        "referer": "https://de.fi/",
                    }
                    my_proxy = random.choice(proxy_list)
                    response = requests.get(
                        url,
                        headers=headers,
                        proxies={"http": f"http://{my_proxy}", "https": f"http://{my_proxy}"},
                    )
                    response.raise_for_status()
                    response_json = response.json()
                    total_usd = int(response_json[address]["totalUsd"])
                    total_usd_str = str(total_usd) + "$"

                    if total_usd > 0:
                        output = "+--------------------+--------------------------------------------------------------------+\n"
                        output += f"| Balance............| {utils.bcolors.GREEN + total_usd_str + utils.bcolors.END}\n"
                        output += f"| Seed...............| {mnemonic}\n"
                        output += f"| Private Key........| {private_key}\n"
                        output += f"| Address............| {address}\n"
                        output += f"| Depth..............| {i+1}\n"
                        output += f"| Chain..............| {chain_name}\n"

                        tokens = response.json()[address]["tokens"]
                        for token in tokens:
                            total_value = int(token["totalValue"])
                            symbol = token["token"]["symbol"]
                            while len(symbol) != 19:
                                symbol += "."

                            if total_value > 0:
                                output += f"| {symbol}| {total_value}$\n"

                        print(output)
                        utils.write_to_excel([mnemonic, private_key, address, i+1, chain_name, total_usd], f"{path_results}/with_balance.xlsx", "balance")
                    else:
                        output = "+--------------------+--------------------------------------------------------------------+\n"
                        output += f"| Balance............| {utils.bcolors.RED + total_usd_str + utils.bcolors.END}\n"
                        output += f"| Seed...............| {mnemonic}\n"
                        output += f"| Private Key........| {private_key}\n"
                        output += f"| Address............| {address}\n"
                        output += f"| Depth..............| {i+1}\n"
                        output += f"| Chain..............| {chain_name}\n"
                        print(output)
                        utils.write_to_excel([mnemonic, private_key, address, i+1, chain_name, total_usd], f"{path_results}/no_balance.xlsx", "balance")
                    break
                except:
                    time.sleep(3)
                    continue


def defi_private(selected_chains_evm, proxy_list, path_results, private_key):
    try:
        address = blocksmith.EthereumWallet.generate_address(private_key)
    except:
        return 0
    
    for chain_id, chain_name in selected_chains_evm.items():
        while True:
            try:
                ua = UserAgent()
                url = f"https://api.de.fi/v1/balances-v2?addresses[]={address}&chains[]={chain_id}"
                headers = {
                    "User-Agent": ua.random,
                    "Pragma": "no-cache",
                    "Accept": "*/*",
                    "origin": "https://de.fi",
                    "referer": "https://de.fi/",
                }
                my_proxy = random.choice(proxy_list)
                response = requests.get(
                    url,
                    headers=headers,
                    proxies={"http": f"http://{my_proxy}", "https": f"http://{my_proxy}"},
                )
                response.raise_for_status()
                response_json = response.json()
                total_usd = int(response_json[address]["totalUsd"])
                total_usd_str = str(total_usd) + "$"

                if total_usd > 0:
                    output = "+--------------------+--------------------------------------------------------------------+\n"
                    output += f"| Balance............| {utils.bcolors.GREEN + total_usd_str + utils.bcolors.END}\n"
                    output += f"| Private Key........| {private_key}\n"
                    output += f"| Address............| {address}\n"
                    output += f"| Depth..............| 1\n"
                    output += f"| Chain..............| {chain_name}\n"

                    tokens = response.json()[address]["tokens"]
                    for token in tokens:
                        total_value = int(token["totalValue"])
                        symbol = token["token"]["symbol"]
                        while len(symbol) != 19:
                            symbol += "."

                        if total_value > 0:
                            output += f"| {symbol}| {total_value}$\n"

                    print(output)
                    utils.write_to_excel(["-", private_key, address, 1, chain_name, total_usd], f"{path_results}/with_balance.xlsx", "balance")
                else:
                    output = "+--------------------+--------------------------------------------------------------------+\n"
                    output += f"| Balance............| {utils.bcolors.RED + total_usd_str + utils.bcolors.END}\n"
                    output += f"| Private Key........| {private_key}\n"
                    output += f"| Address............| {address}\n"
                    output += f"| Depth..............| 1\n"
                    output += f"| Chain..............| {chain_name}\n"
                    print(output)
                    utils.write_to_excel(["-", private_key, address, 1, chain_name, total_usd], f"{path_results}/no_balance.xlsx", "balance")
                break
            except:
                time.sleep(3)
                continue


def usd_price(chains, proxy_list):
    usd_prices = {}
    for chain in chains:
        while True:
            try:
                my_proxy = random.choice(proxy_list)
                response = requests.get(
                    f"https://coincodex.com/api/coincodex/get_coin/{chain}",
                    proxies={"http": f"http://{my_proxy}", "https": f"http://{my_proxy}"},
                )
                usd_prices[chain] = float(response.json()["last_price_usd"])
                break
            except Exception as e:
                time.sleep(3)
                continue
    return usd_prices


def blockcypher_mnemonic(chains, proxy_list, path_results, usd_prices, depth, mnemonic):
    for chain in chains:
        if chain == "ltc":
            cc = LitecoinMainnet
        elif chain == "doge":
            cc = DogecoinMainnet
        elif chain == "dash":
            cc = DashMainnet
        elif chain == "btc":
            cc = BitcoinMainnet

        for i in range(depth):
            try:
                bip44_hdwallet: BIP44HDWallet = BIP44HDWallet(cryptocurrency=cc)
                bip44_hdwallet.from_mnemonic(mnemonic=mnemonic)
                bip44_hdwallet.clean_derivation()
                bip44_derivation: BIP44Derivation = BIP44Derivation(cryptocurrency=cc, account=i, change=False, address=0)
                bip44_hdwallet.from_path(path=bip44_derivation)
                private_key = bip44_hdwallet.private_key()
                address = bip44_hdwallet.address()
            except:
                return 0

            url = f"https://api.blockcypher.com/v1/{chain}/main/addrs/{address}"

            while True:
                try:
                    my_proxy = random.choice(proxy_list)
                    response = requests.get(
                        url,
                        proxies={"http": f"http://{my_proxy}", "https": f"http://{my_proxy}"},
                    )
                    response.raise_for_status()
                    response_json = response.json()
                    balance = response_json["balance"] / 100000000
                    total_usd = balance * usd_prices[chain]
                    total_usd_str = str(total_usd) + "$"

                    if total_usd > 0:
                        output = "+--------------------+--------------------------------------------------------------------+\n"
                        output += f"| Balance............| {utils.bcolors.GREEN + str(total_usd_str) + utils.bcolors.END}\n"
                        output += f"| Seed...............| {mnemonic}\n"
                        output += f"| Private Key........| {private_key}\n"
                        output += f"| Address............| {address}\n"
                        output += f"| Depth..............| {depth}\n"
                        output += f"| Chain..............| {chain}\n"
                        print(output)
                        utils.write_to_excel([mnemonic, private_key, address, depth, chain, total_usd], f"{path_results}/with_balance.xlsx", "balance")
                    else:
                        output = "+--------------------+--------------------------------------------------------------------+\n"
                        output += f"| Balance............| {utils.bcolors.RED + str(total_usd_str) + utils.bcolors.END}\n"
                        output += f"| Seed...............| {mnemonic}\n"
                        output += f"| Private Key........| {private_key}\n"
                        output += f"| Address............| {address}\n"
                        output += f"| Depth..............| {depth}\n"
                        output += f"| Chain..............| {chain}\n"
                        print(output)
                        utils.write_to_excel([mnemonic, private_key, address, depth, chain, total_usd], f"{path_results}/no_balance.xlsx", "balance")
                    break
                except:
                    time.sleep(3)
                    continue


def blockcypher_privates(proxy_list, path_results, usd_prices, private_key):
    try:
        address = blocksmith.BitcoinWallet.generate_address(private_key)
    except:
        return 0
    
    url = f"https://api.blockcypher.com/v1/btc/main/addrs/{address}"

    while True:
        try:
            my_proxy = random.choice(proxy_list)
            response = requests.get(
                url,
                proxies={"http": f"http://{my_proxy}", "https": f"http://{my_proxy}"},
            )
            response.raise_for_status()
            response_json = response.json()
            balance = response_json["balance"] / 100000000
            total_usd = balance * usd_prices["btc"]
            total_usd_str = str(total_usd) + "$"

            if total_usd > 0:
                output = "+--------------------+--------------------------------------------------------------------+\n"
                output += f"| Balance............| {utils.bcolors.GREEN + str(total_usd_str) + utils.bcolors.END}\n"
                output += f"| Private Key........| {private_key}\n"
                output += f"| Address............| {address}\n"
                output += f"| Depth..............| 1\n"
                output += f"| Chain..............| btc\n"
                print(output)
                utils.write_to_excel(["?", private_key, address, 1, "btc", total_usd], f"{path_results}/with_balance.xlsx", "balance")
            else:
                output = "+--------------------+--------------------------------------------------------------------+\n"
                output += f"| Balance............| {utils.bcolors.RED + str(total_usd_str) + utils.bcolors.END}\n"
                output += f"| Private Key........| {private_key}\n"
                output += f"| Address............| {address}\n"
                output += f"| Depth..............| 1\n"
                output += f"| Chain..............| btc\n"
                print(output)
                utils.write_to_excel(["?", private_key, address, 1, "btc", total_usd], f"{path_results}/no_balance.xlsx", "balance")
            break
        except:
            time.sleep(3)
            continue
