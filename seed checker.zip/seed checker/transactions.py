import utils
import blocksmith

from web3 import Web3
from hdwallet import BIP44HDWallet
from hdwallet.cryptocurrencies import EthereumMainnet
from hdwallet.derivations import BIP44Derivation


def evm_mnemonic(rpcs, path_results, depth, mnemonic):
    for i in range(depth):
        try:
            bip44_hdwallet: BIP44HDWallet = BIP44HDWallet(cryptocurrency=EthereumMainnet)
            bip44_hdwallet.from_mnemonic(mnemonic=mnemonic)
            bip44_hdwallet.clean_derivation()
            bip44_derivation: BIP44Derivation = BIP44Derivation(cryptocurrency=EthereumMainnet, account=i, change=False, address=0)
            bip44_hdwallet.from_path(path=bip44_derivation)
            private_key = bip44_hdwallet.private_key()
            address = bip44_hdwallet.address()
        except:
            return 0

        is_good = False
        chain = "-"
        for rpc in rpcs:
            if is_good:
                break

            try:
                w3 = Web3(Web3.HTTPProvider(rpc))
                checksum_address = Web3.to_checksum_address(address)
                total_transactions = w3.eth.get_transaction_count(checksum_address)
                if total_transactions > 0:
                    is_good = True
                    chain = rpc
            except Exception as e:
                pass

        if is_good:
            output = "+--------------------+--------------------------------------------------------------------+\n"
            output += f"| Transactions.......| {utils.bcolors.GREEN + str(total_transactions) + utils.bcolors.END}\n"
            output += f"| Seed...............| {mnemonic}\n"
            output += f"| Pricate Key........| {private_key}\n"
            output += f"| Address............| {address}\n"
            output += f"| Chain..............| {chain}\n"
            output += f"| Depth..............| {i+1}\n"
            print(output)
            with open(f"{path_results}/with_transactions.txt", "a", errors="ignore") as f:
                f.write(f"{mnemonic}\n")
        else:
            output = "+--------------------+--------------------------------------------------------------------+\n"
            output += f"| Transactions.......| {utils.bcolors.RED + str(total_transactions) + utils.bcolors.END}\n"
            output += f"| Seed...............| {mnemonic}\n"
            output += f"| Pricate Key........| {private_key}\n"
            output += f"| Address............| {address}\n"
            output += f"| Chain..............| {chain}\n"
            output += f"| Depth..............| {i+1}\n"
            print(output)
            with open(f"{path_results}/no_transactions.txt", "a", errors="ignore") as f:
                f.write(f"{mnemonic}\n")


def evm_privates(rpcs, path_results, private_key):
    try:
        address = blocksmith.EthereumWallet.generate_address(private_key)
    except:
        return 0

    is_good = False
    chain = "-"
    for rpc in rpcs:
        if is_good:
            break

        try:
            w3 = Web3(Web3.HTTPProvider(rpc))
            checksum_address = Web3.to_checksum_address(address)
            total_transactions = w3.eth.get_transaction_count(checksum_address)
            if total_transactions > 0:
                is_good = True
                chain = rpc
        except Exception as e:
            pass

    if is_good:
        output = "+--------------------+--------------------------------------------------------------------+\n"
        output += f"| Transactions.......| {utils.bcolors.GREEN + str(total_transactions) + utils.bcolors.END}\n"
        output += f"| Private Key........| {private_key}\n"
        output += f"| Address............| {address}\n"
        output += f"| Chain..............| {chain}\n"
        output += f"| Depth..............| 1\n"
        print(output)
        with open(f"{path_results}/with_transactions.txt", "a", errors="ignore") as f:
            f.write(f"{private_key}\n")
    else:
        output = "+--------------------+--------------------------------------------------------------------+\n"
        output += f"| Transactions.......| {utils.bcolors.RED + str(total_transactions) + utils.bcolors.END}\n"
        output += f"| Pricate Key........| {private_key}\n"
        output += f"| Address............| {address}\n"
        output += f"| Chain..............| {chain}\n"
        output += f"| Depth..............| 1\n"
        print(output)
        with open(f"{path_results}/no_transactions.txt", "a", errors="ignore") as f:
            f.write(f"{private_key}\n")
