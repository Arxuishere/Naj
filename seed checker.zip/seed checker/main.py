import configparser
import os
import time
import platform

from bounded_pool_executor import BoundedProcessPoolExecutor
from tkinter import filedialog

import utils
import balance
import transactions



if __name__ == "__main__":
    # title
    utils.set_title("Seed Checker 1.3.0")

    # enable ansi
    system_type = platform.system()
    if system_type == "Windows":
        os.system("color")

    # results
    timestamp = int(time.time())
    path_results = utils.get_file_path(f"results/{timestamp}")
    if not os.path.exists(path_results):
        os.makedirs(path_results)

    # data
    selected_chains_evm = {}
    selected_chains_other = []
    proxy_list = []

    # config
    config = configparser.ConfigParser()
    config.read(utils.get_file_path("settings.ini"))

    threads = int(config["MAIN"]["threads"])
    depth = int(config["MAIN"]["depth"])
    source_type = config["MAIN"]["source_type"]
    mode = config["MAIN"]["mode"]
    run_nonstop = config["MAIN"].getboolean("run_nonstop")
    display_only_balance = config["MAIN"].getboolean("display_only_balance")
    use_proxy = config["MAIN"].getboolean("use_proxy")

    check_evm = config["CHAINS"].getboolean("check_evm")
    check_btc = config["CHAINS"].getboolean("check_btc")
    check_ltc = config["CHAINS"].getboolean("check_ltc")
    check_doge = config["CHAINS"].getboolean("check_doge")
    check_dash = config["CHAINS"].getboolean("check_dash")
    check_eth = config["CHAINS"].getboolean("check_eth")
    check_bnb = config["CHAINS"].getboolean("check_bnb")
    check_polygon = config["CHAINS"].getboolean("check_polygon")
    check_fantom = config["CHAINS"].getboolean("check_fantom")
    check_arbitrum = config["CHAINS"].getboolean("check_arbitrum")
    check_avalanche = config["CHAINS"].getboolean("check_avalanche")
    check_gnosis = config["CHAINS"].getboolean("check_gnosis")
    check_celo = config["CHAINS"].getboolean("check_celo")
    check_moonriver = config["CHAINS"].getboolean("check_moonriver")
    check_harmony = config["CHAINS"].getboolean("check_harmony")
    check_heco = config["CHAINS"].getboolean("check_heco")
    check_okx = config["CHAINS"].getboolean("check_okx")
    check_cronos = config["CHAINS"].getboolean("check_cronos")
    check_boba = config["CHAINS"].getboolean("check_boba")
    check_kucoin = config["CHAINS"].getboolean("check_kucoin")
    check_optimism = config["CHAINS"].getboolean("check_optimism")
    check_aurora = config["CHAINS"].getboolean("check_aurora")
    check_klaytn = config["CHAINS"].getboolean("check_klaytn")
    check_fuse = config["CHAINS"].getboolean("check_fuse")
    check_milkomeda = config["CHAINS"].getboolean("check_milkomeda")
    check_kava = config["CHAINS"].getboolean("check_kava")
    check_zksync = config["CHAINS"].getboolean("check_zksync")
    check_zksyncera = config["CHAINS"].getboolean("check_zksyncera")

    if check_eth:
        selected_chains_evm[1] = "ETH"
    if check_bnb:
        selected_chains_evm[2] = "BNB"
    if check_polygon:
        selected_chains_evm[3] = "Polygon"
    if check_fantom:
        selected_chains_evm[4] = "Fantom"
    if check_arbitrum:
        selected_chains_evm[5] = "Arbitrum"
    if check_avalanche:
        selected_chains_evm[6] = "Avalanche"
    if check_gnosis:
        selected_chains_evm[7] = "Gnosis"
    if check_celo:
        selected_chains_evm[8] = "Celo"
    if check_moonriver:
        selected_chains_evm[9] = "Moonriver"
    if check_harmony:
        selected_chains_evm[10] = "Harmony"
    if check_heco:
        selected_chains_evm[11] = "Heco"
    if check_okx:
        selected_chains_evm[13] = "OKX"
    if check_cronos:
        selected_chains_evm[14] = "Cronox"
    if check_boba:
        selected_chains_evm[15] = "BOBA"
    if check_kucoin:
        selected_chains_evm[16] = "Kucoin"
    if check_optimism:
        selected_chains_evm[17] = "Optimism"
    if check_aurora:
        selected_chains_evm[18] = "Aurora"
    if check_klaytn:
        selected_chains_evm[20] = "Klayth"
    if check_fuse:
        selected_chains_evm[21] = "Fuse"
    if check_milkomeda:
        selected_chains_evm[30] = "Milkomeda"
    if check_kava:
        selected_chains_evm[41] = "Kava"
    if check_zksync:
        selected_chains_evm[42] = "zkSync"
    if check_zksyncera:
        selected_chains_evm[47] = " zkSyncEra"
    if check_btc:
        selected_chains_other.append("btc")
    if check_ltc:
        selected_chains_other.append("ltc")
    if check_doge:
        selected_chains_other.append("doge")
    if check_dash:
        selected_chains_other.append("dash")

    rpc_eth = "https://ethereum.publicnode.com"
    rpc_bnb = "https://bsc.publicnode.com"
    rpc_polygon = "https://polygon-bor.publicnode.com"
    rpc_arbitrum = "https://arbitrum-one.publicnode.com"
    rpc_op = "https://optimism.publicnode.com"
    rpc_avalanche = "https://avalanche-c-chain.publicnode.com"
    rpc_cronos = "https://cronos-evm.publicnode.com"
    rpc_kava = "https://kava-evm.publicnode.com"
    rpc_pulse = "https://pulsechain.publicnode.com"
    rpc_fantom = "https://fantom.publicnode.com"
    rpc_klaytn = "https://1rpc.io/klay"
    rpc_celo = "https://rpc.ankr.com/celo"
    rpc_moonriver = "https://rpc.api.moonriver.moonbeam.network"
    rpc_harmony = "https://1rpc.io/one"
    rpc_okx = "https://exchainrpc.okex.org"
    rpc_boba = "https://boba-mainnet.gateway.pokt.network/v1/lb/623ad21b20354900396fed7f"
    rpc_aurora = "https://endpoints.omniatech.io/v1/aurora/mainnet/public"
    rpc_fule = "https://fuse-mainnet.chainstacklabs.com"
    rpc_base = "https://1rpc.io/base"
    rpc_fusion = "https://mainnet.fusionnetwork.io"
    rpc_rsk = "https://public-node.rsk.co"
    rpc_gnosis = "https://rpc.gnosischain.com"
    rpc_huobi = "https://http-mainnet-node.huobichain.com"
    rpc_astar = "https://1rpc.io/astr"
    rpc_moonbeam = "https://rpc.api.moonbeam.network"
    rpc_canto = "https://canto.slingshot.finance"
    rpc_mantle = "https://mantle.publicnode.com"
    rpc_metis_andromeda = "https://metis-mainnet.public.blastapi.io"
    rpc_telos = "https://mainnet.telos.net/evm"
    rpc_kcc = "https://kcc-rpc.com"

    rpcs = [
        rpc_arbitrum,
        rpc_avalanche,
        rpc_bnb,
        rpc_eth,
        rpc_fantom,
        rpc_polygon,
    ]

    path_source = filedialog.askopenfilename(title="Select text file with seeds or private keys", filetypes=(("Text files", "*.txt"),))
    if mode == "balance":
        path_proxies = filedialog.askopenfilename(title="Select text file with proxies", filetypes=(("Text files", "*.txt"),))
        with open(path_proxies, "r", encoding="utf-8") as f:
            for line in f.readlines():
                proxy_list.append(line.strip())

    # load sources
    sources = []
    with open(path_source, "r", encoding="utf8") as f:
        if source_type == "seeds":
            for mnemonic in f.readlines():
                mnemonic = mnemonic.strip()
                mnemonic_len = len(mnemonic.split(" "))
                if mnemonic_len == 12 or mnemonic_len == 18 or mnemonic_len == 24:
                    sources.append(mnemonic)
        elif source_type == "privates":
            for private_key in f.readlines():
                sources.append(private_key.strip())

    sources = list(set(sources))
    start = time.time()
    
    if mode == "balance":
        if len(selected_chains_other) > 0:
            usd_price = balance.usd_price(selected_chains_other, proxy_list)
        with BoundedProcessPoolExecutor(max_workers=threads) as executor:
            for source in sources:
                try:
                    if len(selected_chains_evm) > 0:
                        if source_type == "seeds":
                            executor.submit(balance.defi_mnemonic, selected_chains_evm, proxy_list, path_results, depth, source)
                        elif source_type == "privates":
                            executor.submit(balance.defi_private, selected_chains_evm, proxy_list, path_results, source)
                    if source_type == "seeds" and len(selected_chains_other) > 0:
                        executor.submit(balance.blockcypher_mnemonic, selected_chains_other, proxy_list, path_results, usd_price, depth, source)
                    elif source_type == "privates" and check_btc:
                        executor.submit(balance.blockcypher_privates, proxy_list, path_results, usd_price, source)
                except KeyboardInterrupt:
                    print("\nStopping all threads...")
                    break
                except Exception as e:
                    with open("errors.txt", "a", encoding="utf8", errors="ignore") as f:
                        f.write(e + "\n")

    elif mode == "transactions":
        with BoundedProcessPoolExecutor(max_workers=threads) as executor:
            for source in sources:
                try:
                    if source_type == "seeds":
                        executor.submit(transactions.evm_mnemonic, rpcs, path_results, depth, source)
                    elif source_type == "privates":
                        executor.submit(transactions.evm_privates, rpcs, path_results, source)
                except KeyboardInterrupt:
                    print("\nStopping all threads...")
                    break
                except Exception as e:
                    with open("errors.txt", "a", encoding="utf8", errors="ignore") as f:
                        f.write(e + "\n")

    end = int(time.time() - start)
    input(f"Finished in {end} seconds")
